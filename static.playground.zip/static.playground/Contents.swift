import UIKit

class Visitor {
  var name: String
  var visitDate: Date
  
  init(name: String, visitDate: Date) {
    self.name = name
    self.visitDate = visitDate
    
    Visitor.numberOfVisitors += 1
    
  }
  static var numberOfVisitors = 0
  
  static func generateVisitors(count: Int) -> [Visitor] {
    var generateVisitors: [Visitor] = []
    
    for _ in 1...count {
      let randomName = "Visitor \(Int.random(in: 1...100))"
      let randomDate = Date().addingTimeInterval(TimeInterval.random(in: -45678...0))
      let visitor = Visitor(name: randomName, visitDate: randomDate)
      generatedVisitors.append(visitor)
    }
    
    return generateVisitors
  }
}

var generatedVisitors = Visitor.generateVisitors(count: 5)

print("Total number of generated visitors: \(Visitor.numberOfVisitors)")
