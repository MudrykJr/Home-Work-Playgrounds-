import Cocoa

let today = Date()

let event1 = ("Friend's BD", 10, 10, 2023)
let event2 = ("Meeting with colleagues", 11,10, 2023)

let calendar = Calendar.current
let todayComponents = calendar.dateComponents([.day, .month, .year], from: today)

if todayComponents.day == event1.1 &&
    todayComponents.month == event1.2 &&
    todayComponents.year == event1.3 {
  print("today \(event1.0)")
} else if let tomorrow = calendar.date(byAdding: .day, value: 1, to: today) {
  let tomorrowComponents = calendar.dateComponents([.day, .month, .year], from: tomorrow)
  
  if tomorrowComponents.day == event2.1 &&
      tomorrowComponents.month == event2.2 &&
      tomorrowComponents.year == event2.3 {
    print("Tomorrow \(event2.0) will begin")
  } else {
    print("No upcoming event for today")
  }
}
