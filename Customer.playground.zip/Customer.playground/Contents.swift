import UIKit

//Tuples: Customer

var customer: (name: String, isPartner: Bool, sum: Float) = ("Johan", false, 1000)

//Buying sum
let currentSum = customer.sum

var discount: Float = 0.0

switch customer.sum {
case 0...500: discount = 0.0
case 501...1100: discount = 0.1
case 1111...2000: discount = 0.15
  
default: discount = 0.25
}

if customer.isPartner {
  if discount == 0.0 {
    discount = 0.05
  } else {
    discount *= 2
  }
}

let finalSum = currentSum - (currentSum * discount)
var gift = ""

switch customer.sum {
case 500: gift = "Your gift is 🥝"
case 1000: gift = "Your gift has increased, now it's 🍟"
case 1111: gift = "Now you are getting the highest discount, your gift is 🍏🍎🍏"
  
default: gift = "There isn't a gift for you"
}

print("customer name \(customer.name)")
if customer.isPartner {
  print("Customer is partner")
}
print("Price without discount: \(currentSum)")
print("Your discount is \(discount * 100)%")
print("Price with discount: \(finalSum)")
print(gift)
